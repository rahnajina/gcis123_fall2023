'''
TITLE: GCIS BONUS ACTIVITY

The following python code is a script which is specifically designed for task scheduling. It organizes the tasks based 
on their dependencies, making sure the tasks are executed in proper order.

FUNCTIONS:

mirror(dict) - This function essentially mirros the original structure making it easier to identify which tasks depend on a
particular task. The function takes one arguement (dict) which is a dictionary with a set of keys and values.
It initializes an empty dictionary (dependancy_task) and iteraves over each pair. After following a set of
commands it returns dependency_task which is a mirror of the input dictionary.


remove_value(list_tasks, t, dict) - This function is part of the task schedulling process. It updates the dependency lists by
removing the specific task t from the lists assosiated with the input tasks in list_tasks. 
After indentifying the tasks whose dependency lists are empty it returns the elements in the
empty_tasks lists.


schedule(dict) - This function is made to schedule tasks based on their dependencies. It identifies the tasks that can be
started first and then iteratively schedules tasks, updating the dependency list as tasks are scheduled. The
final schedule is returned as a list. After continous cycles if the depenecies is preventing a schedule it
returns 'None'.

Done by Mohamed Armaan and Abderrahmane Nait Brahim
'''
tasks_dependencies = {"T3":["T2","T1"], "T2":["T1"], "T1":[]}

def mirror(dict):

    dependency_tasks = {}

    # Reading all the keys and values in the passed dictionary
    for task, deps in dict.items():

        # Iterating over the list of dependencies
        for value in deps:
            # Checking if the dependency already exists in the new dictiaonry in the form of a key
            if value in dependency_tasks:
                # If it does, add the dependency as a new element to the list
                dependency_tasks[value].append(task)
            else:
                # If it does not, then make key-pair value
                dependency_tasks[value] = [task]      
    return dependency_tasks

def remove_value(list_tasks,t,dict):

    empty_task = []
    
    for task in list_tasks:
        # Check if the task is in the dictionary
        if task in dict:
            # Remove t from the values associated with the current task
            if t in dict[task]:
                dict[task].remove(t) # Check if the values for the current task are now empty
                
            # The not operator returns True if a list is empty in python
            if not dict[task]: 
                empty_task.append(task)
    return empty_task

def schedule(dict):

    # List to store ordered tasks
    scheduled_tasks = []

    # loop that runs until all tasks are scheduled
    while dict:

        # Finding tasks with no remaining prerequisites
        available_tasks = [task for task, deps in dict.items() if not deps]

        # If there are no available tasks and there are remaining dependencies,
        # return an empty list since no valid schedule is possible
        if not available_tasks:
            return []

        # Iterate through available tasks
        for task in available_tasks:
            # Add task to the schedule
            scheduled_tasks.append(task)
            # Remove task from the dictionary
            del dict[task]

            # Update dependencies for remaining tasks
            for deps in dict.values():
                if task in deps:
                    deps.remove(task)

    # print the final ordered list of tasks
    print(scheduled_tasks)


schedule(tasks_dependencies)